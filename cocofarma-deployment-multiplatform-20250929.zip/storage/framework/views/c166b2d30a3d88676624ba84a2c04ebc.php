<style>
    footer {
      margin-top: auto;
      padding-top: 40px; /* Added top padding for spacing */
      background: #1d1b31;
      color: #f1f5f9;
      text-align: center;
      padding: 17.5px;
      font-size: 14px;
    }

    footer p {
      text-align: center;
      margin: 0;
    }

    footer a {
      color: #60a5fa;
      text-decoration: none;
      margin: 0 8px;
    }

    footer a:hover {
      text-decoration: underline;
    }
</style>
<footer>
    <p>© 2025 Cocofarma | Dibuat dengan ❤️ oleh Tim Developer D3MI</p>
</footer><?php /**PATH D:\CODE\XAMPP\XAMPP-8.2.12\htdocs\cocofarma\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>